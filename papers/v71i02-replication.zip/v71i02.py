# protoc histogram.proto --python_out=.

from histogram_pb2 import HistogramState;
hist = HistogramState()
hist.counts.extend([2, 6, 2, 4, 6])
hist.breaks.extend(range(6))
hist.name = "Example Histogram Created in Python"
outfile = open("/tmp/hist.pb", "wb")
outfile.write(hist.SerializeToString())
outfile.close()

# protoc rexp.proto --python_out=.
import urllib2
from rexp_pb2 import REXP
req = urllib2.Request("https://demo.ocpu.io/MASS/data/Animals/pb")
res = urllib2.urlopen(req)
msg = REXP()
msg.ParseFromString(res.read())
print(msg)
